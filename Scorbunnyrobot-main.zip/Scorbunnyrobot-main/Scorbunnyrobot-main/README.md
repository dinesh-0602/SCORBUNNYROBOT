# EMCEE GROUP MANAGER BOT

EMCEE IS ADVANCE GROUP MANAGER BOT FOR GEEKS 
 HAVING FUNCTIONS OF MULTIPLE BOTS IN 1 BOT
 DONT FORGET TO ADD [EMCEE](https://t.me/emcee_bot) in your respective groups
  
And join [emcee Support](https://t.me/emcee_supoort) if you have any queries
# deploy

CLICK ON BELOW IMAGE TO DEPLOY ON HEROKU 

[![DEPLOY](https://telegra.ph/file/0ef205e512d6454449b5f.jpg)](https://heroku.com/deploy?template=https://github.com/Aquila-14/EMCEE)

Keep supporting us 😊



# ref

Your beloved:-

[EMCEE DEVS](https://t.me/Emcee_Devs)
 

